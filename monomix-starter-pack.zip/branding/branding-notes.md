# Monomix Branding

**Font:** Orbitron (Google Fonts)  
**Style:** Futuristic, clean, minimal, dark-mode friendly  
**Color Palette (example):**
- Primary: #00FFFF (Cyan)
- Secondary: #0A0A0A (Jet Black)
- Accent: #FF0099 (Magenta)

Logos and media assets will be added here once finalized.
